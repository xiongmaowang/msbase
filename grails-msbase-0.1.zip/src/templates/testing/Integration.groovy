@artifact.package@import grails.test.spock.IntegrationSpec

class @artifact.name@ extends IntegrationSpec {

    def setup() {
    }

    def cleanup() {
    }

    void "com.ms.test something"() {
    }
}