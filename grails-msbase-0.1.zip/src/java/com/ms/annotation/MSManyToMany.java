package com.ms.annotation;

/**
 * Created by zmd on 2016/12/13.
 */
public @interface MSManyToMany {
}
