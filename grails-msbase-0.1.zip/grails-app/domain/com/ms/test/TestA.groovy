package com.ms.test

import com.ms.annotation.MSAction
import com.ms.annotation.MSActions
import com.ms.annotation.MSDomain
import com.ms.annotation.MSField
import com.ms.base.User
import com.ms.file.AttachMent
import com.ms.systemEnum.MSActionType

@MSActions(msAction = [
	@MSAction(actionType = MSActionType.SAVEORUPDATE ,msFileds = [
			@MSField(name = "testP.testPName",label="testP"  ),
			@MSField(name = "testP.testCs",label="testP"  ),
			@MSField(name = "attachMent",label="testP"  ),
	]),
	@MSAction(actionType = MSActionType.DELETE  ),
	@MSAction(actionType = MSActionType.TABLEVIEWSEARCH ,msFileds = [
			@MSField(name = "testP",label="testP" ),
	])
])
@MSDomain(name = "A",controllerPackage = "com.ms.test",viewPackage = "com/ms/test")
class TestA {
	def springSecurityService
	static transients = ["springSecurityService"]
	String id
	String testAName
	TestP testP
	AttachMent attachMent
	//创建日期
	Date dateCreated
	Date lastUpdated
	User userCreated
	User userUpdated
    static constraints = {
    }
	static mapping = {
	}
	def beforeInsert() {
		userCreated = springSecurityService?.getCurrentUser()
		userUpdated = springSecurityService?.getCurrentUser()
	}

	def beforeUpdate() {
		userUpdated = springSecurityService?.getCurrentUser()
	}
}
