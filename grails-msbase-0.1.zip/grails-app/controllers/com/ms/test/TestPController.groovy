/**
 * 创建自 xmw on 2017-02-05.
 */

package com.ms.test
import com.ms.base.util.GridDataUtil 
import grails.converters.JSON 
import com.ms.test.TestP 

class TestPController {

    static defaultAction ="testPTableS"


    def testPSave(){
        withForm {
            boolean result =true
            def testP
            if(params.id){
                testP= TestP.get(params.id)

            }else{
                testP=new TestP()
            }
            
            testP.properties['testA','testPName'] = params
            testP.clearErrors()
            			
			def saveObj=testP
			if(testP.testA){
			    testP.testA.testP=testP
			    saveObj=testP.testA
			}

            if(!saveObj.save(flush:true)){
                result=false
            }
            render ([result:result] as JSON)
        }.invalidToken {
        // bad request
        }
    }

    def testPSaveView(){
        def testP=new TestP()
        if(params.id){
            testP = TestP.get(params.id)
        }
        render view:'/testP/testPSave', model:[testP:testP]
    }


    def testPDelete(){
        def model=[:]
        def result=true
        params.ids.split(',').grep()?.each{
        def testP =TestP.get(it)
            if(testP){
                //testP.testA?testP.testA.testP=null:null
                testP.delete()
            }else{
                result=false
            }
        }
        model["result"]=result
        render ( model as JSON)
    }

    def testPTableS(){
        def model =[domainClass:TestP.class]
        withFormat{
            html {
                render view:'/testP/testPTableS' , model:model
            }
            json{
                def query={map->
					if(map.searchs["testA"]!=null){
						eq("testA",map.searchs["testA"])

					}
                }
                render GridDataUtil.gridList(model['domainClass'],params,query,true) as JSON
            }
        }
    }


}
