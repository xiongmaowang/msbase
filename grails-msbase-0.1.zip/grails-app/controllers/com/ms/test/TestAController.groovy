/**
 * 创建自 xmw on 2017-02-07.
 */

package com.ms.test
import com.ms.base.util.GridDataUtil 
import grails.converters.JSON 
import com.ms.test.TestA 

class TestAController {

    static defaultAction ="testATableS"


    def testASave(){
        withForm {
            boolean result =true
            def testA
            if(params.id){
                testA= TestA.get(params.id)

            }else{
                testA=new TestA()
            }
            
            testA.properties['testP','attachMent'] = params
            testA.clearErrors()
            			
			testA.testP.testCs?.clear()
			params["testCs"]?.split(",")?.grep()?.each{
			    def testC =com.ms.test.TestC.get(it)
			    testA.testP.addToTestCs(testC) 
			}

            if(!testA.save(flush:true)){
                result=false
            }
            render ([result:result] as JSON)
        }.invalidToken {
        // bad request
        }
    }

    def testASaveView(){
        def testA=new TestA()
        if(params.id){
            testA = TestA.get(params.id)
        }
        render view:'/com/ms/test/testASave', model:[testA:testA]
    }


    def testADelete(){
        def model=[:]
        def result=true
        params.ids.split(',').grep()?.each{
        def testA =TestA.get(it)
            if(testA){
                testA.delete()
            }else{
                result=false
            }
        }
        model["result"]=result
        render ( model as JSON)
    }

    def testATableS(){
        def model =[domainClass:TestA.class]
        withFormat{
            html {
                render view:'/com/ms/test/testATableS' , model:model
            }
            json{
                def query={map->
					if(map.searchs["testP"]!=null){
						eq("testP",map.searchs["testP"])

					}
                }
                render GridDataUtil.gridList(model['domainClass'],params,query,true) as JSON
            }
        }
    }


}
