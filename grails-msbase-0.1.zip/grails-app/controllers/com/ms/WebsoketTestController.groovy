package com.ms

class WebsoketTestController {

    def index() { render view: "index" }
}
